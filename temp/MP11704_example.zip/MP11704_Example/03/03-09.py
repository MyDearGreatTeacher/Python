for i in range(200, 0, -1):
	if i%17 == 0:
		print(i)
		break

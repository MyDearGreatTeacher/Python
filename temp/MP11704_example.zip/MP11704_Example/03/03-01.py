age = 24
subject = "電腦"
college = "非重點"
if (age > 25 and subject=="電子資訊工程") or (college=="重點" and subject=="電子資訊工程" ) or (age<=28 and subject=="電腦"):
    print("恭喜，您已獲得敝公司的面試機會!")
else:
    print("抱歉，您未達到面試要求")

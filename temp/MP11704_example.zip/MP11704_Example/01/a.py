def test():
    print('test in a.py')

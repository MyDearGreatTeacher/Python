def test():
    print('test in b.py')

class Car(object):		#定義一個類別，派生繼承自object類別
	def infor(self):	#定義成員方法
		print(" This is a car ")
